/*
SQLyog Community v13.1.7 (64 bit)
MySQL - 8.0.26 : Database - sleepdb
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`sleepdb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `sleepdb`;

/*Table structure for table `answer` */

DROP TABLE IF EXISTS `answer`;

CREATE TABLE `answer` (
  `Qu_ID` int(4) unsigned zerofill NOT NULL,
  `Client_ID` int(6) unsigned zerofill NOT NULL,
  `Date` date NOT NULL,
  `Answer` varchar(2000) NOT NULL,
  PRIMARY KEY (`Qu_ID`,`Client_ID`,`Date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `answer` */

insert  into `answer`(`Qu_ID`,`Client_ID`,`Date`,`Answer`) values 
(0001,529475,'2022-03-23','23:11'),
(0001,837068,'2022-03-21','11:11'),
(0002,529475,'2022-03-23','23:12'),
(0002,837068,'2022-03-21','11:11'),
(0003,529475,'2022-03-23','1'),
(0003,837068,'2022-03-21','1'),
(0004,529475,'2022-03-23','2'),
(0004,837068,'2022-03-21','1'),
(0005,529475,'2022-03-23','11:11'),
(0005,837068,'2022-03-21','11:11'),
(0006,529475,'2022-03-23','11:22'),
(0006,837068,'2022-03-21','11:11'),
(0007,529475,'2022-03-23','meletonin'),
(0007,837068,'2022-03-21','test'),
(0008,529475,'2022-03-23','2'),
(0008,837068,'2022-03-21','2'),
(0009,529475,'2022-03-23','possible'),
(0009,837068,'2022-03-21','sore'),
(0010,000001,'2022-03-14','1 '),
(0010,014724,'2022-03-14','1 '),
(0010,701400,'2022-05-06','1 '),
(0011,000001,'2022-03-14','3'),
(0011,014724,'2022-03-14','4'),
(0011,701400,'2022-05-06','4'),
(0012,000001,'2022-03-14','4'),
(0012,014724,'2022-03-14','4'),
(0012,701400,'2022-05-06','5'),
(0013,000001,'2022-03-14','4'),
(0013,014724,'2022-03-14','3'),
(0013,701400,'2022-05-06','3'),
(0014,000001,'2022-03-14','1 '),
(0014,014724,'2022-03-14','1 '),
(0014,701400,'2022-05-06','4'),
(0015,000001,'2022-03-14','3'),
(0015,014724,'2022-03-14','3'),
(0015,701400,'2022-05-06','0'),
(0016,000001,'2022-03-14','3'),
(0016,014724,'2022-03-14','3'),
(0016,701400,'2022-05-06','4'),
(0017,014724,'2022-03-07','3'),
(0018,014724,'2022-03-07','3'),
(0019,014724,'2022-03-07','3'),
(0020,014724,'2022-03-07','43'),
(0021,014724,'2022-03-07','2'),
(0022,014724,'2022-03-07','2');

/*Table structure for table `client` */

DROP TABLE IF EXISTS `client`;

CREATE TABLE `client` (
  `Client_ID` int(6) unsigned zerofill NOT NULL,
  `Com_ID` int(4) unsigned zerofill NOT NULL,
  `First_Name` varchar(70) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Phone` varchar(14) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `Email` varchar(200) NOT NULL,
  `Account_Type` int NOT NULL,
  `Last_Name` varchar(70) NOT NULL,
  PRIMARY KEY (`Client_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `client` */

insert  into `client`(`Client_ID`,`Com_ID`,`First_Name`,`Phone`,`Email`,`Account_Type`,`Last_Name`) values 
(014724,0001,'common','1234567890','common@common.ca',1,'common'),
(029728,0001,'fred','2131231234','tom@tommon.ca',1,'tot'),
(038504,0001,'kentaurus','(234)-123-4321','Kentaurus@gmail.com',1,'middleson'),
(142914,0001,'Clark','(111)-222-3333','common6@common.ca',1,'Dyck'),
(147491,0001,'test','(222)-222-2222','test@user.ca',1,'user2'),
(153868,0001,'test','(333)-444-5555','testuser2@test.ca',1,'user'),
(195391,0001,'first','(111)-222-3333','email@email.ca',1,'last'),
(211761,0001,'Michael','1234567890','Pat.Bauhuis@shaw.ca',2,'McDosentExist'),
(258532,7064,'0','0','0',1,'0'),
(305351,0001,'Clark','(123)-123-1234','test@email.ca',2,'Dyck'),
(337350,0001,'0','0','0',1,'0'),
(395756,0002,'0','0','0',1,'0'),
(423564,0002,'0','0','0',1,'0'),
(480995,0001,'test','(111)-222-3333','test@test2.ca',1,'more'),
(511807,0001,'test','(111)-222-3333','test3@test.ca',1,'user'),
(529475,0001,'email','(112)-331-2345','client@client.ca',2,'test'),
(593025,0001,'0','0','0',1,'0'),
(626011,0001,'0','0','0',1,'0'),
(659602,0001,'0','0','0',1,'0'),
(663587,0001,'testing','(123)-123-1234','more@testing.ca',1,'again'),
(701400,0002,'name','(222)-333-4444','common2@common.ca',1,'otherName'),
(702158,0001,'sos','(123)-123-1234','common3@common.ca',1,'frarf'),
(704582,0001,'Admin','0000000000','admin@admin',3,'Admin'),
(710046,0001,'Clark','(123)-123-1234','clarkdyck@gmail.com',0,'Dyck'),
(766844,0002,'0','0','0',1,'0'),
(837068,0001,'tom','1231231234','client@sleepapp.ca',2,'test'),
(857366,0002,'0','0','0',1,'0'),
(898611,0001,'0','0','0',0,'0'),
(907410,0001,'0','0','0',1,'0'),
(940675,0001,'0','0','0',1,'0'),
(958571,0001,'test','(123)-123-1234','test@test.ca',0,'subject');

/*Table structure for table `company` */

DROP TABLE IF EXISTS `company`;

CREATE TABLE `company` (
  `Com_ID` int(4) unsigned zerofill NOT NULL,
  `Com_Name` varchar(30) NOT NULL,
  `Com_Email` varchar(200) NOT NULL,
  `Com_Phone` varchar(11) NOT NULL,
  `Com_Memo` varchar(280) NOT NULL,
  PRIMARY KEY (`Com_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `company` */

insert  into `company`(`Com_ID`,`Com_Name`,`Com_Email`,`Com_Phone`,`Com_Memo`) values 
(0001,'Individual','0','0','All clients unassociated with a company'),
(0002,'Test_Company','test@company.ca','0','company to test the workings of getCompanyName function'),
(7064,'asdf','fdsa','1231231234','this is a company ');

/*Table structure for table `password` */

DROP TABLE IF EXISTS `password`;

CREATE TABLE `password` (
  `Client_ID` varchar(200) NOT NULL,
  `Password` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`Client_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `password` */

insert  into `password`(`Client_ID`,`Password`) values 
('038246f4e16f698457091b2063c0c6c19bd275a205a5ed2aaadc571d87a88d8896ef8b3ea630a4b7b9144279b2d15c8ca399f1e95b54ac08888e35bf5525cb0e','0000'),
('0a21d35fb0df92421b93cec0d8c15cfc7588f0e24c42b50f2f7905e060b17e3ea217b35c50add5a5358cfe120b498628a03e97985421a4c8c79ff8bbb96b5439','0000'),
('161c394def4632b1f2fa79165880791feb0aa735cb5b422ce792149c78a17c8e9566b765b61694d34050cbd3e36b1b272c7c77b2e5c8fbb82598a2ad88e167cf','0000'),
('259b7cbf94750dc58df77e30d8ba65fb64885ecee5e1c6f9d6c2aa0796194001cf2ed110220d5c1d60e372c131167ecca03652b3930e44cdad85a04b6a46d4eb','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('299b1417590c79de97fb41f6a3610661529d84369a2b31f827c35de5f907989294701812710ff0fad896bdf51bae71a6492a8f902cb2675e52bc701919dc322e','0000'),
('2c80742b1fe253637fd7e3e9cd49c4984093845c7b3132457c0f674920372435c83ddb8f2665342f0706c2e314457bff2de27b32c01bb4d061000f211a350560','0000'),
('3e9a0bda66032d8ea0847f8196a7e6803318365eb67e17c8a9d55b22aacffcba47d6e62ca90dafe5d65bccfed38df27dc8bf6799eba8a1456a24c4a9450cf179','cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'),
('46adecc24753e65e4454c8fd15ce4bba9ff3b4d195f0f3f15efeb3cfc4572ee9adb17a9e4c91ae39525dc7350da2f1d60a36998ee052b151fcfc4a0914731ab5','c7ad44cbad762a5da0a452f9e854fdc1e0e7a52a38015f23f3eab1d80b931dd472634dfac71cd34ebc35d16ab7fb8a90c81f975113d6c7538dc69dd8de9077ec'),
('55f6bcf5e67f5ce4985e9f95a55830a208603204ba740bbaa645584a328ecffb371a1c8b9d54e229c3bbccb685e0264a462fea67a7ddd7bd1b4dbd84d7cb6603','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('5ede00c620b87e2910f8e4be9c0a3ae8aa0db71a98d0992fb21faf5533e06715ca5cc038590910958acc17222cfc27d6113f9f1ecb63ff09bce571091b5f77dd','d404559f602eab6fd602ac7680dacbfaadd13630335e951f097af3900e9de176b6db28512f2e000b9d04fba5133e8b1c6e8df59db3a8ab9d60be4b97cc9e81db'),
('62d6aff0bff3aadb8af573f5143c139ec8a05ef3b9807c1fd9448831fe950c03dda0bea1b9657f0314cd996debbf25edd0ab95c9e04d2fb60967e763b22a2eff','0000'),
('662b7a5f5103acfa5211778fab3890c220d0c58562ff2865473748f8e73e34a2ed478c17036566e28fa9d9051ffd710a28e145b3ac553bc2abb8d61c0bbfde87','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('739f92db38308e362882c8cb23f84a3ba6cbbce9c3547aa6c41f9d0f13a0719cd3fdde9673ecdd95159520cc6cb9618efd7fe4e66827eb5cf7f20b46e7745236','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('758e234011b5eedee44a40a3f3e1a7361acf4de7cfa33e8ec270c25ea91dbebb70041a9f1abb5dd3f1489d97d79f92049025479c087881a609c1456f550216cf','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('7c27225878a49d9541f6a6bf1488f9da8c233aeff8934c9a2f20d240e66f436f327a51855c09aab9a1a59b19e3fd857fbde2069e8ae6e79d5b6130bbf9926164','0000'),
('86b52b1b20f7f6cc501e27590bba2819d375ba4d3622391f9df692090208b28616ffaff73a4bc096d344eb9dd34fa24d50fdbe86033fe6cc900ca9cb4aa001a6','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86'),
('888e6d19f633c48c96cff332e41bc1ee16268ce4a24a2e7487dd7f1b84bffcc9c0b8d251f0c5f16aba8cdb27128ce3c84e2a480aab88ce35a881344a3eefb144','b109f3bbbc244eb82441917ed06d618b9008dd09b3befd1b5e07394c706a8bb980b1d7785e5976ec049b46df5f1326af5a2ea6d103fd07c95385ffab0cacbc86'),
('8a4728c09687346917d2a57b143ea2b8abebd9bc4cf17f94eca9737038fac8e4e091a6ee70dc00b62fb27cf855d281f6f44b2ce1c27f3919cd98acb4717422e8','cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'),
('9d340b8849901378ca8054d6f09c0f2eca6cfea7c4eaba7fb37226db70b0ea58e129e65113f9fd37bce0c5f80a3c77a18a3230046d03acc3c91242ca79f450f6','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('9fdf49dbdb04fc38bc75c95888df0248cb4fe8bb5c4fa650188b420a48f60b45fc8b5dae100f20bab65bb1bff689bd0553a527bd901a174f7f28f01c2c846db3','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('a0a97f9be0b8c25cdd6c5a67fa809094ebf05eedc48f0da685f7c50caec7593bf561a8afbf51f53243b88f460778a4a33b0fc5c7d9fd7d88f8f39f87d4c97c07','0000'),
('a4a49e81298b6f4025401ee2e59d06eb20fc4e9196a2f961c9cb586b48eba88589cc78463afca545f33ae837973dce68a3a5a7d283477f16bb64ba8d1b4525dd','0000'),
('a916c528b82b2265aaae77343bd2a18b7338d30ee75dedfbf7654d0a28dfe8975d6c8c66b552d8cc1e157a7fc85c7ea2cf7e5f74488feece4d1917a0bf359a19','0000'),
('aea47f5f1e05081bc67e3933b3979eadd9cb234d5d913ab2fc6e1b05c47ea097f52991fdd811158c86536c988e778c8e469d504fdeb3232db5a5a928c82d5df2','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('b7d6db4812a7d3febfd6338e1ee28a879ae0a9cdb33309572ab7eb3b9f30db2f4da17a4c68284025bf6609a1c0ef3befbe323d5b269af2814436187f2ad96419','0000'),
('bfa19c334d6ba53e520e5ec48d36e55334d7c552f558bb2e2982c956ec3dc7beaf1a9d5632e9a6fd1766e0f60b4d6215e420a38c5febab69d192505208188218','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('c38037f48e4b53d97bdd704e2a471ba465084b73095fd4d951f2c8df60892ab967006bd14fc13dbb47039463da5b59f81f8486a36c2ecb5b9148b0dc84ca1405','0000'),
('c3c1f645407046340dc063de92159a0725d5f792164bfd5b2f9c77726b65343328adcb5d6714894c39cc21cb272b1e34153b1e7d22c6c8c2ada0202ff6b98c72','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('ce8ed94a314113734672e41c8e1d23e2ee82f32ad0e7a403c7f2f5847e9e2dca24a1ed2a92783fb4d96d97df06ebaca5921fbef01ed5bd158e3654fb3dd6010e','cf83e1357eefb8bdf1542850d66d8007d620e4050b5715dc83f4a921d36ce9ce47d0d13c5d85f2b0ff8318d2877eec2f63b931bd47417a81a538327af927da3e'),
('ed766bbc7a2636bf55f10b2fe58a1270d46e23cd09a3e3c9e8a02610fef01ef650443beec303b54f337773e18d963da5c5d3cd701916357a29ca11327ad4f03f','0000'),
('f4109da6eb3c983a6a6b05932d4804e500227a79d27b1202b2b86162054661a0488d043f9c3e1efe516758e0ebd0330590c4805c753808b74d5be9d1d4f2cf5a','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25'),
('fcd1f095836be44cd07d9e2d718e793067d51f42e3c8aad64fdfe4757a508c544e08c0274a2aecddd0fac5c64074f92d3489e74acb44272ee09a125c78e0fd8f','5b722b307fce6c944905d132691d5e4a2214b7fe92b738920eb3fce3a90420a19511c3010a0e7712b054daef5b57bad59ecbd93b3280f210578f547f4aed4d25');

/*Table structure for table `question` */

DROP TABLE IF EXISTS `question`;

CREATE TABLE `question` (
  `Qu_ID` int(4) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `Sur_ID` int(4) unsigned zerofill NOT NULL,
  `Question` varchar(2000) NOT NULL,
  PRIMARY KEY (`Qu_ID`,`Sur_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=1123 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `question` */

insert  into `question`(`Qu_ID`,`Sur_ID`,`Question`) values 
(0001,0001,'What time did you go to bed? '),
(0002,0001,'What time did you turn off the lights? '),
(0003,0001,'How long did it take you to fall asleep?(in hours).'),
(0004,0001,'How many times did you wake up last night?'),
(0005,0001,'About how long were you awake during the night?(Total of all awakenings)'),
(0006,0001,'What was your final wake up time this morning?'),
(0007,0001,'What time did you get out of bed?'),
(0008,0001,'About how many hours did you sleep last night?'),
(0009,0001,'Time allotted for sleep (lights out until get out of bed)'),
(0010,0001,'Sleep Medications(indicate dose and type)'),
(0011,0001,'Rate your sleep 1-5 (1 = very poor, 5 = very good)'),
(0012,0001,'Notes- possible circumstances that might  have contributed to how you slept.'),
(0013,0002,'Difficulty falling asleep'),
(0014,0002,'Difficulty staying asleep'),
(0015,0002,'Problems waking up too early'),
(0016,0002,'How SATISFIED/DISSATISFIED are you with your CURRENT sleep pattern?'),
(0017,0002,'How NOTICEABLE to others do you think your sleep problem is in terms of impairing the quality of your life? '),
(0018,0002,'How WORRIED/DISTRESSED are you about your current sleep problem?'),
(0019,0002,'To what extent do you consider your sleep problem to INTERFERE with your daily functioning (e.g. daytime fatigue, mood, ability to function at work/daily chores, concentration, memory, mood, etc.) CURRENTLY?'),
(0020,0003,'During the past seven days, how many hours did you miss from work because of your sleep problems? Include hours you missed on sick days, times you went in late, left early, etc., because of your sleep problems.'),
(0021,0003,'During the past seven days, how many hours did you miss from work because of other health problems? Include hours you missed on sick days, times you went in late, left early, etc., because of your health problems.'),
(0022,0003,'During the past seven days, how many hours did you miss from work because of any other reason, such as vacation, holidays, sick kids? '),
(0023,0003,'During the past seven days, how many hours did you actually work? '),
(0024,0003,'During the past seven days, how much did your sleep problems affect your productivity while you were working? '),
(0025,0003,'During the past seven days, how much did your sleep problems affect your ability to do your regular daily activities, other than work at a job?'),
(0026,0004,'How many nights per week do you usually have difficulty falling asleep?'),
(0027,0004,'On the nights you have trouble going to sleep, how long on average does it usually take you to fall asleep after going to bed?'),
(0028,0004,'How many nights per week do you wake up in the middle of the night and have difficulty falling back to sleep?'),
(0029,0004,'On average, how many times do you wake up per night?'),
(0030,0004,'On nights you have difficulty sleeping, how long on average are you awake during the night? (total of all the times you\'re awake)'),
(0031,0004,'How many days a week do you wake up early in the morning, before your scheduled wake time, and are unable to return to sleep?'),
(0032,0004,'On nights when you have insomnia, approximately how long do you sleep each night?'),
(0033,0004,'On nights when you don\'t have insomnia, how long do you sleep?'),
(0034,0004,'What time do you usually get into bed at night?'),
(0035,0004,'How soon do you turn off the lights to go to sleep?'),
(0036,0004,'What time do you usually get out of bed in the morning?'),
(0037,0004,'How long would you like to be able to sleep each night?'),
(0038,0004,'Do you use your bed for activities other than sleep or sexual activity?'),
(0039,0004,'At this time, how much stress would you say there is in your life?'),
(0040,0004,'How often do you take naps?'),
(0041,0004,'Do you practice any type of relaxation technique?'),
(0042,0004,'If yes, what type? (check all that apply)'),
(0043,0004,'Does difficulty sleeping ever affect your mood or functioning during the day?'),
(0044,0004,'If yes, how is your mood or functioning affected. (check all that apply)'),
(0045,0004,'Are you sleepy during the day? (sleepy means nodding off, or could close eyes and go to sleep)'),
(0046,0004,'Do you wake with aches and pains?'),
(0047,0004,'On weekends or your days off, do you sleep more than an hour later than your usual wake up time?'),
(0048,0004,'What do you do to relax prior to bedtime? (check all that apply)'),
(0049,0004,'How long have you had sleep problems?'),
(0050,0004,'Is your sleep problem sometimes worse than other times?'),
(0051,0004,'Was the onset of your sleep problem related to any specific event?'),
(0052,0004,'How often is your sleep disturbed by environmental factors such as traffic, neighbors, or family members?'),
(0053,0004,'Do you engage in some kind of regular physical exercise?'),
(0054,0004,'If yes, describe the kind, frequency, and time of day. (put N/A if it doesn\'t apply to you)'),
(0055,0004,'How many cups or glasses of caffeinated beverages (e.g. coffee, tea, or cola) do you drink in a day?'),
(0056,0004,'How often do you drink caffeinated beverages after 4 p.m.?'),
(0057,0004,'Do you use alcohol to aid sleep?'),
(0058,0004,'About how often and how much alcohol do you drink, not necessarily for sleep? (Alcohol affects your ability to sleep, this is to help assess whether your sleeplessness could be affected by alcohol consumption)'),
(0059,0004,'Do you use recreational drugs?'),
(0060,0004,'Do you smoke?'),
(0061,0004,'Have you recently taken any prescription or over-the-counter medication for sleeping problems?'),
(0062,0004,'If yes, what medication and amount are you taking? (put N/A if it doesn\'t apply to you)'),
(0063,0004,'How many nights a week do you usually take this medication?'),
(0064,0004,'How long have you been taking sleeping medication?'),
(0065,0004,'Do you snore?'),
(0066,0004,'Do you ever wake up in the night and feel unable to breathe?'),
(0067,0004,'Do your legs ever jerk repeatedly or feel restless after you go to bed at night?'),
(0068,0004,'Is there a history of sleeping difficulties in your family?'),
(0069,0004,'Have you previously been evaluated or treated for sleeping problems?'),
(0070,0004,'If yes, describe. (put N/A if it doesn\'t apply to you)'),
(0071,0004,'Have you tried any self-help remedies for you sleeping problems?'),
(0072,0004,'If yes, describe. (put N/A if it doesn\'t apply to you)'),
(0073,0004,'Do you engage in any of these activities?'),
(0074,0004,'What are some of the most important learnings or strategies that you are using to keep your sleep on track?');

/*Table structure for table `survey` */

DROP TABLE IF EXISTS `survey`;

CREATE TABLE `survey` (
  `Sur_ID` int(4) unsigned zerofill NOT NULL,
  `Sur_Name` varchar(150) NOT NULL,
  PRIMARY KEY (`Sur_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

/*Data for the table `survey` */

insert  into `survey`(`Sur_ID`,`Sur_Name`) values 
(0001,'Daily Survey'),
(0002,'Insomnia Severity Survey'),
(0003,'WPAI'),
(0004,'Pre/Post-Assesment');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
