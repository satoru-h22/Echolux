<?php
session_start();
if (isset($_SESSION['accountType']) && $_SESSION['accountType'] == 0){
	
	header('Location: unlogged.php');
	
	}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}

?>
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Sleep App | Home</title>
  <link rel="stylesheet" href="sleepApp.css">
 
</head>
<style>
.wrapper {
  margin: 0;
  display: grid;
  grid-template-areas:
    "header nav"
    "main main"
    "footer footer";
  width: 100%;
}

header {
  grid-area: header;
  color: white;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
  
}
nav {
  grid-area: nav;
  color: #c4e3ec;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}

article {
  grid-area: main;
  color: #243236;
  background-color: #8fc9d9;
  width: 100%;
  height: 650px;
}

footer {
  grid-area: footer;
  background-color: #48656d;
  width: 100%;
  height: 50px;
}

a {
  color: #243236;
}

  h1.appName {
  text-align: center;
}

.homeBox {
  width: 40%;
  background-color: #c4e3ec;
  text-align: center;
  margin: 20px auto;
}
p {
  font-size: 0.75em;
  margin-top: -10px;
}

.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
</style>
<body>
    <div class="wrapper">
		<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
		<div>
			<nav>
				<a href="adminHome.php">Home</a>
				<a href="generateNewAccount.php">Generate New Account</a>
				<a href="viewAccounts.php">View Accounts</a>
				<a href="export.php">Export DB</a>
				<a href="createCompany.php">Create Company</a>
				<br>
				<form action="" method="post">
					<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
				</form>
			</nav>
		</div>
        <article>
          <!-- This section is for the content-->
          <h1 class='appName'>App name</h1>
              <div class="homeBox">
                <h3><a href="generateNewAccount.php">Generate New Account</a></h3>
                <p>Create New Accounts</p>
              </div>
              <div class="homeBox">
                <h3><a href="export.php">Export DB</a></h3>
                <p>Export entire database to csv</br>Look for the ability to export selected clients in a future update</p>
              </div>
			  <div class="homeBox">
                <h3>Create New Company</h3>
                <p>Check for the ability to create companies in a future update</p>
              </div>
              
              
              
          

        </article>
        <footer></footer>
    </div>
</body>
</html>