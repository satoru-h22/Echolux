<?php
session_start();
	
include 'config.php';
include "createUpdateAccount.php";

if (isset($_SESSION['accountType']) && $_SESSION['accountType'] == 0){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}
elseif(isset($_REQUEST['create'])){
	
	$times = $_REQUEST['noAccount'];
	$companyName = $_REQUEST['companyName'];
	$arrayID = [];
	$companyID = getCompanyID($companyName);
	if ($companyID != 0){
		for ($i = 0; $i < $times; $i++){
		
			$arrayID["$i"] = generateNewAccount($companyID);
		}
		$_REQUEST['IDs'] = $arrayID;
		createUpdateAccount();
		
	}
	else{
		
		echo"<script>alert('Company name $companyName not accepted. Please try again')</script>";
		
	}
}
elseif (isset($_REQUEST['view'])){
	
	header('Location: viewAccounts.php');
	
}



?>

	
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sleep App | Profile</title>
	<link rel="stylesheet" href="sleepApp.css">
</head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.dropdown {
  float: left;
  overflow: hidden;
}
.dropdown .dropbtn {
  font-size: 1.2em;
  border: none;
  outline: none;
  color: #8fc9d9;
  font-weight: bold;
  background-color: inherit;
  font-family: inherit;
  padding: 5px 15px 0px 15px;
}

nav a:hover,
.dropdown:hover .dropbtn {
  color: #243236;
  border-top: 4px solid #243236;
  font-weight: bold;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #c4e3ec;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: #243236;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  border: none;
  color: #fff;
  background-color: #243236;
}

.dropdown:hover .dropdown-content {
  display: block;
}
h1.appName {
  font-size: 2em;
  text-align: center;
}


/* Full-width input fields */
input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 1px solid #ccc;
  background: #f1f1f1;
  box-sizing: border-box;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(228, 220, 220);
  outline: rgb(5, 5, 5);
}
.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
hr {
	width 50%;
}
input[type=text], input[type=number] {
	width: 35%;
	padding: 12px 20px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #ccc;
	box-sizing: border-box;
	text-align: center;
}

select {
	width: 35%;
	padding: 12px 20px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #ccc;
	box-sizing: border-box;
	text-align: center;
}

form label {
	font-size: 16;
}
</style>

<body>
	<div class="wrapper">
		<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
	
		<nav>
				<a href="adminHome.php">Home</a>
				<a href="generateNewAccount.php">Generate New Account</a>
				<a href="viewAccounts.php">View Accounts</a>
				<a href="export.php">Export DB</a>
				<a href="createCompany.php">Create Company</a>
				<br>
				<form action="" method="post">
					<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
				</form>
			</nav>
		 

		<article>
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
				
				<div class="container">

					<div class="profile">
						<div style="border-bottom: 1px solid #243236;">
							<h2>Generate New Account</h2>
						</div>
						
						<div style="border-bottom: 1px solid #243236;">
							
							<br><br>
							<label for="firstn"><b>Number of accounts to Create:</b></label>

							<br>
									  
							<div style="display: inline;">

							<div>
							
							</br><input type='number' placeholder='Enter Number of accounts' value='1' name='noAccount' required>
								
							</div>

							<br>

							</div>                    
						
							<label for="firstn"><b>Select Company</b></label>

							<br><br>
									
							<div style="display: inline;">

							<select id="ansq2" name="companyName">
							
							<?php	
							//get company names with company ID and put them into a associative array with the ID pointing to the name
							//used to populate the dropdown and associate names with IDs for insertion into the database
							$sql = "SELECT Com_Name, Com_ID FROM company";
							$result = $conn->query($sql);
							$array = array();
							while ($row = $result -> fetch_assoc())  {
								$array[$row['Com_ID']] = $row['Com_Name'];
							}

							foreach($array as $name){
			
								echo"<option value=$name>$name</option>";
				
							}
				
							?>
							
							</select>
  
								<br><br><br>

							</div>    
						<button type="submit" value="create" name="create">Create Account</button>
						<br><br>
						</div>
						
						<button type="submit" value="View" name="view">View Empty Accounts</button>

							  
					
				</div>

				  
			</form>
		</article>
	</div>
</body>
<footer></footer>
</html>