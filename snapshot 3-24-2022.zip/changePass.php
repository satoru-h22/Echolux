<?php
include 'createUpdateAccount.php';
include 'config.php';
session_start();
//ensure no one can access this page without being logged in first
if (!isset($_SESSION['clientID'])){
	
	header('Location: unlogged.php');
	
}


if(isset($_REQUEST['submit']) && $_REQUEST['currentPass'] != null && $_REQUEST['pass'] != null && $_REQUEST['pass2'] != null){
	
	$_REQUEST['changePass'] = '1';
	createUpdateAccount();
	
}
else{
	//make sure it doesn't show an alert the first time a user comes to the site
	if(!isset($_REQUEST['submit'])) {
		
		//do nothing load html
		
	}
	else{
	echo'<script>alert("Please fully complete the form")</script>';
	}
}

//return to profile if cancel is selected
if(isset($_REQUEST['cancel'])){
	
	header('Location: profile.php');
	
}

?>


<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="sleepApp.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;
          background-color: #48656D;}
form {border: 3px solid black;
  background-color: #8FC9D9;}

input[type=email], input[type=password] {
  width: 40%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  background: #f1f1f1;
  box-sizing: border-box;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(228, 220, 220);
  outline: rgb(5, 5, 5);
}

button {
  background-color: #243236;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 25%;
}

button:hover {
  opacity: 0.8;
}

.cancelbtn {
  width: auto;
  padding: 10px 18px;
  background-color: #243236;
}

.imgcontainer {
  text-align: center;
  margin: 24px 0 12px 0;
}

.container {
  padding: 20px;
  
text-align: center;
}

span.psw {
  float: center;
  padding-top: 10px;
}

/* Change styles for span and cancel button on extra small screens */
@media screen and (max-width: 300px) {
  span.psw {
     display: block;
     float: none;
  }
  .cancelbtn {
     width: 100%;
  }
}
</style>
</head>

<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
<body>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
  <div class="imgcontainer">
   <h2>Change Password</h2>
  </div>

  <div class="container">
    <label for="Password"><b>Current Password</b></label>
    <br>
    <input type="Password" placeholder="Enter Current Password" name="currentPass">
    <br>
    <label for="Password"><b>Password</b></label>
    <br>
    <input type="Password" placeholder="Enter Password" name="pass">
	<br>
	<label for="Password"><b>Repeat Password</b></label>
    <br>
    <input type="Password" placeholder="Repeat Password" name="pass2">
        <br>
		
	<button type="submit" name="submit">Submit</button>
    <button type="submit" name="cancel">Cancel</button>

  </div>

  <div class="container" style="background-color:#8FC9D9">
    
  </div>
</form>
</body>
</html>