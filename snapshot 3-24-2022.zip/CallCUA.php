<?php
//include "createUpdateAccount.php";
//connect to database
//include 'config.php';
session_start();
print_r($_POST);
print_r($_REQUEST);
print_r($_SESSION);
//comments for testing individual processes

//testing non admin clients
//$_SESSION["admin"] = "0";
//$_SESSION["clientID"] = "2893";
//$account = generateNewAccount('0001');
//echo"$account";
//createUpdateAccount();
//$name = getCompanyName('0001');
//echo"$name";
//$ID = getCompanyID('Test Company');
//echo"$ID";
//$editClientID = 0;

?>