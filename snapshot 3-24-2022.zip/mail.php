<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.wrapper {
  margin: 0;
  display: grid;
  grid-template-areas:
    'header nav'
    'main main'
    'footer footer';
  width: 100%;
}
.headerS {
  color: #c4e3ec;
  font-size: 4em;
  margin-top: 0px;
  margin-right: 0.25em;
  margin-left: 0.25em;
}
.headerLogo {
  font-size: 1.5em;
  line-height: 1.2em;
  font-weight: bold;
  margin-bottom: 10px;
  margin-right: 0.5em;
}
.headerSub {
  font-size: 0.9em;
  color: #c4e3ec;
  font-weight: bold;
  line-height: 1.5em;
  margin-bottom: 10px;
}
header {
  grid-area: header;
  color: white;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
  display: flex;
  align-items: flex-end;
}

nav {
  grid-area: nav;
  color: #c4e3ec;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}
article {
  grid-area: main;
  background-color: #8fc9d9;
  width: 100%;
  min-height: 500px;
  height: auto;
  text-align: center;
  padding: 10px;
}
footer {
  grid-area: footer;
  background-color: #48656d;
  width: 100%;
  height: 50px;
  padding: 10px;
}
</style>
</head>
<body>
	<div class='wrapper'>
		<header>
			<div class='headerS'>/ </div>
			<div class='headerLogo'>Lana Walsh<br>Coaching</div>
			<div class='headerSub'>Sleep Coach: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
		</header>
		<nav></nav>
		<article>
		<br><br><br>
		<div style='border: solid 4px; border-color: black; background-color: #c4e3ec; width: 50%; margin-left:25%'>
			<h3><?=$title?></h3>
		</div>
		<br>
			<span><?=$preLink?> <a href='<?=$link?>'><?=$linkText?></a></span>
		
		</article>
	</div>
	<footer></footer>
</body>
</html>