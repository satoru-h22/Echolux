<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
//Load Composer's autoloader
require 'vendor/autoload.php';

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);


try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'emlynsworkshop@gmail.com';                     //SMTP username
    $mail->Password   = 'jackotheshadows';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('LanaWalshCoaching@SleepApp.com', 'Lana Walsh Coaching');
	//Add a recipient
    $mail->addAddress('clark.dyck@lethbridgecollege.ca');               //Name is optional
	//no reply
    //$mail->addReplyTo('info@example.com', 'Information');
	//no need to cc or bcc
	//$mail->addCC('cc@example.com');
	//$mail->addBCC('bcc@example.com');
	
	
	//attachments unnecessary 
    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
	//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'setup account';
    $mail->Body    = '<!DOCTYPE html>
<html>
<head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.wrapper {
  margin: 0;
  display: grid;
  grid-template-areas:
    "header nav"
    "main main"
    "footer footer";
  width: 100%;
}
.headerS {
  color: #c4e3ec;
  font-size: 4em;
  margin-top: 0px;
  margin-right: 0.25em;
  margin-left: 0.25em;
}
.headerLogo {
  font-size: 1.5em;
  line-height: 1.2em;
  font-weight: bold;
  margin-bottom: 10px;
  margin-right: 0.5em;
}
.headerSub {
  font-size: 0.9em;
  color: #c4e3ec;
  font-weight: bold;
  line-height: 1.5em;
  margin-bottom: 10px;
}
header {
  grid-area: header;
  color: white;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
  display: flex;
  align-items: flex-end;
}

nav {
  grid-area: nav;
  color: #c4e3ec;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
  display: flex;
  justify-content: space-around;
  align-items: flex-end;
}
article {
  grid-area: main;
  background-color: #8fc9d9;
  width: 100%;
  min-height: 500px;
  height: auto;
  text-align: center;
  padding: 10px;
}
footer {
  grid-area: footer;
  background-color: #48656d;
  width: 100%;
  height: 50px;
  padding: 10px;
}
</style>
</head>
<body>
	<div class="wrapper">
		<header>
			<div class="headerS">/ </div>
			<div class="headerLogo">Lana Walsh<br>Coaching</div>
			<div class="headerSub">Sleep Coach: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
		</header>
		<nav></nav>
		<article>
		<br><br><br>
		<div style="border: solid 4px; border-color: black; background-color: #c4e3ec; width: 50%; margin-left:25%">
			<h3>Insert helpful text here</h3>
		</div>
		<br>
			<span>non linked text here  <a href="">insert location</a></span>
		
		</article>
	</div>
	<footer></footer>
</body>
</html>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>