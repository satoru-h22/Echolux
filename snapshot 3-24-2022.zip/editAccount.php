<?php

session_start();
include 'config.php';
include "createUpdateAccount.php";
//print_r($_SESSION);
if (isset($_SESSION['accountType']) && $_SESSION['accountType'] == 2){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}






//$j refers to the itteration to display in the edit screen
$j = 0;
//get number of accounts to edit passed through get from header on view Accounts under the edit elseif
$num = $_GET['lastNo'];
//account itteration pointing to client ID
$arrayID = [];
//account itteration pointing to all account data
$account = [];
//loop through the session array until all clientIDs have been saved into $arrayID each time it loops through it unsets the session value for that account as it will be stored in a local array and no longer needs to be in the session array
for($i = 0; $i <= $num; $i++){
	$x = $i . '_client';
	//checkboxes on view account will report values when checked and unchecked (meaning they increase the value of lastNo each time they are checked and unchecked this if statement ensures that the value exists before 
	if(isset($_SESSION[$x])){
	$arrayID[$i] = $_SESSION[$x];
	unset($_SESSION[$x]);
	}
	
}

//account is a multi dementional array consisting of the itteration (number of accounts to edit) pointing to the entirety of the information within the database for that account

foreach($arrayID as $itteration => $clientID){
	//get the account data and insert it into the account array for each instance of an account
	$_REQUEST['editID'] = $clientID;
	$account[$itteration] = getAccountInfo();
	
	
}

//check to see if an account data is available for the itteration number if no account data is found increment the itteration until account data is found 

$row = [];
if(isset($account[$j])){
$row = $account[$j];
$clientID = $row['Client_ID'];
$accountType = $row['Account_Type'];
$accountName = getTypeName($accountType, null);
	print_r($accountName);
	switch($accountName){
		case 'free':
			$free = 'selected';
			$pending = null;
			$client = null;
			$admin = null;
		break;
		case 'pending':
			$free = null;
			$pending = 'selected';
			$client = null;
			$admin = null;
		break;
		case 'client':
			$free = null;
			$pending = null;
			$client = 'selected';
			$admin = null;
		break;
		case 'administrator':
			$free = null;
			$pending = null;
			$client = null;
			$admin = 'selected';
		break;
		default:
			$free = null;
			$pending = null;
			$client = null;
			$admin = null;
			echo"default";
	}
	

$companyID = $row['Com_ID'];
$companyName = getCompanyName($companyID);
$firstName = $row['First_Name'];
$lastName = $row['Last_Name'];
$phone = $row['Phone'];
$email = $row['Email'];
}
else{
	
	$j++;
	
}
if(isset($_REQUEST['next'])){
	
	$j++;
	
}
elseif(isset($_REQUEST['back'])){
	
	$j--;
	
}
?>

<!DOCTYPE html>
<html>
  <head>
  <meta charset="utf-8">
  <title></title>
  <link rel="stylesheet" href="sleepApp.css">
<style>
body {font-family: Arial, Helvetica, sans-serif;
      background-color: #48656D;}
* {box-sizing: border-box}
form {border: 3px solid black;
  background-color: #8FC9D9;}

/* Full-width input fields */
input[type=text], input[type=password], input[type=tel]{
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 1px solid #ccc;
  background: #f1f1f1;
  box-sizing: border-box;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(228, 220, 220);
  outline: rgb(5, 5, 5);
}

hr {
  border: 1px solid #000000;
  margin-bottom: 25px;
}

/* Set a style for all buttons */
button {
  background-color: #243236;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 20%;
  opacity: 0.9;
}

button:hover {
  opacity:0.8;
}


/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
    text-align: center;
  float: center;
  width: 20%;
  padding: 14px 20px;
  background-color: #243236;
}

/* Add padding to container elements */
.container {
  padding: 16px;
  text-align: center;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 20%;
  }
}

select {

}

</style>

  </head>
  <header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
</header>
  <body>

<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method = "post" style="border:1px solid #ccc">
  <div class="container">
    <h1>Editing Client: <?=$clientID?></h1>
    <p>Please fill in this form to Edit the account.</p>
    <hr>
		<label for="First Name"><b>Account Type:</b></label> 
    <br>
		<select id="ansq2" name="accountType">				
			<option value='free'<?=$free?>>Free</option>
			<option value='pending'<?=$pending?>>Pending</option>
			<option value='client'<?=$client?>>Client</option>
			<option value='admin'<?=$admin?>>Administrator</option>
		</select>
    <br><br>
    <label for="firstn"><b>Select Company</b></label>

		<br>
									
		<div style="display: inline;">

			<select id="ansq2" name="companyName" selected="<?=$companyName?>">
							
			<?php	
			//get company names with company ID and put them into a associative array with the ID pointing to the name
			//used to populate the dropdown and associate names with IDs for insertion into the database
			$sql = "SELECT Com_Name, Com_ID FROM company";
			$result = $conn->query($sql);
			$companyNameArray = [];
			while ($row = $result -> fetch_assoc())  {
				$companyNameArray[$row['Com_ID']] = $row['Com_Name'];
			}
			echo"<option value='none'>None</option>";
			foreach($companyNameArray as $name){
			
				echo"<option value=$name>$name</option>";
				
			}
			
			?>
							
			</select>
 
    <br>
	<input type="text" placeholder="Enter First Name" value="<?=$firstName?>" name="editFirstName" required>
	<br>

	<label for="Last Name"><b>Last Name:</b></label> 
    <br>
	<input type="text" placeholder="Enter Last Name" value="<?=$lastName?>" name="editLastName" required>
	<br>

	<label for="Phone Number"><b>Phone Number:</b></label> 
    <br>
	<!--id="phone" can be added to call the javascript-->
	<input id="phone" type="text" name="editPhone"  maxlength="10" value="<?=$phone?>" placeholder="(___)-___-____" required>
	<br>
    
    <label for="Email"><b>Email</b></label> 
    <br>
    <input type="text" placeholder="Enter Email" value="<?=$email?>"  name="editEmail" required>
    <br>
	
    <label for="psw"><b>Password</b></label>
    <br>
    <input type="password" placeholder="Enter Password" name="editPass" required>
    <br>
    <label for="psw-repeat"><b>Repeat Password</b></label>
    <br>
    <input type="password" placeholder="Repeat Password" name="editPass2" required>
    <br>
    
    
    <p>By creating an account you agree to our <a href="#" style="color:dodgerblue">Terms & Privacy</a>.</p>

    <div class="clearfix">
      <button type="submit" name="submit" value="signup" class="signupbtn">Finish</button>
	  <button type="button" name="cancel" value="cancel">Cancel</button>
    </div>
  </div>
</form>

<script type="text/javascript">(function(){window['__CF$cv$params']={r:'6db85c53fe8108f7',m:'fG5v43MlOAEZEhNNXVXY4zIll3KSKPF0Eo0V7eNpFpc-1644527808-0-AV823yX3vMQ3y23l7H21Y1jPpIEGLzuL53YWmTQb2KYFQB5ZGw4LZjt9Cga60iW9YUaCaSIDdHb+r0Esk3iVem3OMc1fY9dKbh5s8jTHTkDyYdWZ5IR1Qtvpa34YpCaJNQkl+H3/sA5yaKuBAE4NRQnCa/rxRLEDlU29ZVPVLxNNj0N0UQxLGma/9Ug48tsVJ9VeCcGI2H1XuATCzrHT5Qs=',s:[0xaac12ca72a,0x8f98fbb6b8],}})();</script></body>
</html>