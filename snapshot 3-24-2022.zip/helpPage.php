<?php
session_start();
if (!isset($_SESSION['clientID'])){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}
?>
<!DOCTYPE html>
<html>

<head>
    <title>Sleep App | Help</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="sleepApp.css">
    <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>-->
    
</head>

<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 15px;
  right: 35px;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 1.2em;
  border: none;
  outline: none;
  color: #8fc9d9;
  font-weight: bold;
  background-color: inherit;
  font-family: inherit;
  padding: 5px 15px 0px 15px;
}

nav a:hover,
.dropdown:hover .dropbtn {
  color: #243236;
  border-top: 4px solid #243236;
  font-weight: bold;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #c4e3ec;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: #243236;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  border: none;
  color: #fff;
  background-color: #243236;
}

.dropdown:hover .dropdown-content {
  display: block;
}

</style>
<body>
    <div class="wrapper">
         <header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
	
	
	
		<nav>
            <a href="home.php">Home</a>
            <div class="dropdown">
              <button class="dropbtn">Surveys
                <i class="fa fa-caret-down"></i>
              </button>
              <div class="dropdown-content">
                <a href="daySurvey.php">Daily Survey</a>
                <a href="ISSI.php">Insomnia Severity Index</a>
                <a href="WPAI.php">Work Productivity and Activity Impairment</a>
              </div>
              </div>
            <a href="profile.php">Profile</a>
            <a href="report.php">Report</a>
			<a href="helpPage.php">Help</a>
			</br>
			<form action="" method="post">
				<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
			</form>
			    
		</nav>

        <article>
            <div class="container">
                <h2>Help</h2>
                <div class="panel-group" id="accordion">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                                <!--<a data-toggle="collapse" data-parent="#accordion" href="#collapse1">-->How to access a
                                    weekly
                                    report?<!--</a>-->
                            </h4>
                        </div>
                        <div id="collapse1" class="panel-collapse collapse in">
                            <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                             <!--   <a data-toggle="collapse" data-parent="#accordion" href="#collapse2">-->How to reset your
                                    password?<!--</a>-->
                            </h4>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse">
                            <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                        </div>
                    </div>
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h4 class="panel-title">
                               <!--  <a data-toggle="collapse" data-parent="#accordion" href="#collapse3">-->How to access
                                    previous week
                                    report?<!--</a>-->
                            </h4>
                        </div>
                        <div id="collapse3" class="panel-collapse collapse">
                            <div class="panel-body">Lorem ipsum dolor sit amet, consectetur adipisicing elit,
                                sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
                                veniam,
                                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</div>
                        </div>
                    </div>
                </div>
				
            </div>
            
            </div>
        </article>
        <footer></footer>

</body>

</html>