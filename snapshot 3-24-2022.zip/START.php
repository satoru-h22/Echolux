<?php
include "createUpdateAccount.php";
//connect to database
//include 'config.php';

//comments for testing individual processes
//session_start();
//testing non admin clients
//$_SESSION["admin"] = "0";
//$_SESSION["clientID"] = "2893";
//generateNewAccount();
createUpdateAccount();
//$editClientID = 0;

?>