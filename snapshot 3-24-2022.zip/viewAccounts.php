<?php
session_start();
include 'config.php';
include "createUpdateAccount.php";
//print_r($_SESSION);
if (isset($_SESSION['accountType']) && $_SESSION['accountType'] == 0){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['return'])){
	
	header('Location: generateNewAccount.php');
	
}
elseif (isset($_REQUEST['reload'])){
	$selectStart = null;
	$selectEnd = null;
	$hidden = 'hidden';
	$hidden2 = 'hidden';
	
}
elseif (isset($_REQUEST['sendMail'])){
	unset($_REQUEST['sendMail']);
	

	prepMail(1);
	
}
elseif (isset($_GET['msg'])){
	
	echo'<script>alert("No accounts selected. Please select an account to edit")</script>';
	
}
elseif (isset($_GET['done'])){
	
	echo'<script>alert("End of list. Returning to View Accounts")</script>';
	
}

else{
	
$selectStart = null;
$selectEnd = null;
$hidden = 'hidden';
$hidden2 = 'hidden';
}

//builds a query for view Accounts that takes each possible input from View Accounts and checks to see if a value has been provided
//It then adds each value to the input array which is used to construct and SQL statement placed into the input array and returns the input array
//it retu
function buildSearch(){
	$input = [];
	//counts how many fields are blank and if they are all blank selects all accounts
	$x = 0;
	//get search terms and determine which terms carry values that are valid for submission to the database
	//checking company select statement
	if($_REQUEST['companyName'] != 'none'){
		$companyName = $_REQUEST['companyName'];
		$companyID = getCompanyID($companyName);
		$input['Com_ID'] = $companyID;
	}
	else{
		
		$x++;
		
	}
	//checking account type select statement
	if($_REQUEST['accountType'] != 'none'){
		$typeID = getTypeID($_REQUEST['accountType']);
		$input['Account_Type'] = $typeID;
								
	}
	else{
		
		$x++;
		
	}
	//check if firstname has a value
	if($_REQUEST['firstName'] != null){
			
		$input['First_Name'] = $_REQUEST['firstName'];
								
	}
	else{
		
		$x++;
		
	}
	//check if last name has a value
	if($_REQUEST['lastName'] != null){
			
		$input['Last_Name'] = $_REQUEST['lastName'];
								
	}
	else{
		
		$x++;
		
	}
	//check if email has value
	if($_REQUEST['email'] != null){
			
		$input['Email'] = $_REQUEST['email'];
								
	}
	else{
		
		$x++;
		
	}
	//check if phone has a value
	if($_REQUEST['phone'] != null){
			
		$input['Phone'] = $_REQUEST['phone'];
								
	}
	else{
		
		$x++;
		
	}
	//if all are null search for all accounts else search based upon criteria
	if ($x == 6){
		
		$sql = 'select * from client';
		
	}
	else{
		
		$sql = 'select * from client where ';
		
	}
	//build sql statement by selecting everything from client where searches provided are the term searched
	//this foreach uses a counter to determine the last term so it won't put an and statement on the end of the last value.
	//this functionality works regardless of how long the input array is
	$i = 1;
	$length = count($input);
	foreach($input as $search => $term){
		if ($i == $length){
			
			$sql .= "$search = '$term' ";
			
		}
		else{
		$sql .= "$search = '$term' and ";
		
		$i++;
		}
	}
	$input['sql'] = $sql;
	
	return $input;
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sleep App | Profile</title>
	<link rel="stylesheet" href="sleepApp.css">
</head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.dropdown {
  float: left;
  overflow: hidden;
}
.dropdown .dropbtn {
  font-size: 1.2em;
  border: none;
  outline: none;
  color: #8fc9d9;
  font-weight: bold;
  background-color: inherit;
  font-family: inherit;
  padding: 5px 15px 0px 15px;
}

nav a:hover,
.dropdown:hover .dropbtn {
  color: #243236;
  border-top: 4px solid #243236;
  font-weight: bold;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #c4e3ec;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: #243236;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  border: none;
  color: #fff;
  background-color: #243236;
}

.dropdown:hover .dropdown-content {
  display: block;
}
h1.appName {
  font-size: 2em;
  text-align: center;
}


/* Full-width input fields */
input[type=text], input[type=email], input[type=tel] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 1px solid #ccc;
  background: #f1f1f1;
  box-sizing: border-box;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(228, 220, 220);
  outline: rgb(5, 5, 5);
}
.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
hr {
	width 50%;
}
input[type=text], input[type=number] {
	width: 35%;
	padding: 12px 20px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #ccc;
	box-sizing: border-box;
	text-align: center;
}

select {
	width: 35%;
	padding: 12px 20px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #ccc;
	box-sizing: border-box;
	text-align: center;
}

form label {
	font-size: 16;
}
table {
   width: 100%;
   margin-bottom: 20px;
   background: #fff;
}

table, table tr, table tr td, table tr th {
	height: 100%;
	
   border: solid 1px #48656d;
}
    tr:first-child {
    background: #c4e3ec;
    }
	tr:nth-child(2){
		background: #c4e3ec;
	}
    td:first-child {
    background: #c4e3ec;
    }
	.container {
  padding: 16px;
  max-width: 900px;
  margin: auto;
  padding: 10px;
  text-align: center;
}


/* Tooltip container */
.tooltip {
  position: relative;
  display: inline-block;
  width: 100%;
  height: 100%;
   
   background: #fff;
}


/* Tooltip text */
.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: black;
  color: #fff;
  text-align: center;
  padding: 5px 0;
  border-radius: 6px;
 
  /* Position the tooltip text - see examples below! */
  position: absolute;
  z-index: 1;
}

/* Show the tooltip text when you mouse over the tooltip container */
.tooltip:hover .tooltiptext {
  visibility: visible;
}
</style>

<body>
	<div class="wrapper">
		<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
	
		<nav>
				<a href="adminHome.php">Home</a>
				<a href="generateNewAccount.php">Generate New Account</a>
				<a href="viewAccounts.php">View Accounts</a>
				<a href="export.php">Export DB</a>
				<a href="createCompany.php">Create Company</a>
				<br>
				<form action="" method="post">
					<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
				</form>
			</nav>
		 

		<article>
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
				
				<div class="container">

					<div class="tableContents">
						<div style="border-bottom: 1px solid #243236;">
							<h2>View Accounts</h2>
						</div>
						
						<div style="border-bottom: 1px solid #243236;">
							
							<br>
							<?php
							
							if (isset($_SESSION['IDs'])){
							//grab the array of IDs that were just created, as well as the company name, and blank the session array where they were.
								$arrayID = [];
								$arrayID = $_SESSION['IDs'];
								$companyName = $_SESSION['companyName'];
								unset($_SESSION['IDs']);
								unset($_SESSION['companyName']);		
								$selectStart = '<!--';
								$selectEnd = '-->';
								$hidden = null;
								$hidden2 = 'hidden';
								$edit = 'hidden';
								$freeAvailable = null;
								echo"<h3>Accounts just created on:<br>$companyName</h3>
									<table>
									<tr>
									<th><h2>Access Code:</h2></th>
									<th><h2>Email Code:</h2></th>
									</tr>";
								$noAccount = count($arrayID);
								for($i = 0; $i < $noAccount; $i++){
									echo"
									<tr>
									<td>$arrayID[$i]</td>
									
									<td><input type='email' placeholder='Email' name='$arrayID[$i]'></td>
									</tr>
									";
									
								}
								echo"</table>";
								
							}
							
							elseif (isset($_REQUEST['edit'])){
							
							//adding selected edit accounts to the session array from the request array so that the data can be preserved through the header to the edit account page
								unset($_REQUEST['edit']);
								foreach ($_REQUEST as $i => $clientID){
									if(isset($_REQUEST[$i])){
									$x = $i . '_client';
									$_SESSION["$x"] = $clientID;
									}
								}
								//testing code
								/*print_r($_REQUEST);
								echo"<br><br>";
								print_r($_SESSION);*/
								
								header("Location: editAccount.php?lastNo=".$i);
								
							}
							
							elseif (isset($_REQUEST['view'])){
								//reformat page to include report data and hide report selection
								$selectStart = '<!--';
								$selectEnd = '-->';
								$hidden = null;
								$hidden2 = 'hidden';
								$freeAvailable = 'hidden';
								$edit = null;
								//checks to see if a free account is available and if it is show send emails button
								
								//get array of search terms and the sql statement
								$searchArray = [];
								$searchArray = buildSearch();
								
								foreach($searchArray as $type => $value){
									if ($type == 'sql'){
										
										$sql = $value;
										unset($searchArray['sql']);
									}
									
									
									
									
								}
								$result = $conn->query($sql);
								//print headers for the account table
								//the if statements allow the presentation of 				
								echo"<h3></h3>
									<table>
									<tr>
									<th><h2>Client ID:</h2></th>
									<th><h2>Last Name:
									</h2></th>
									<th><h2>First Name:</h2></th>
									<th><h2>Email:</h2></th>
									<th><h2>Phone Number:</h2></th>
									<th><h2>Company:</h2></th>
									<th><h2>Account Type:</h2></th>
									<th><h2>Select Account:</h2></th>
									</tr>
									<tr>
									<td><h2>Search Terms:</h2></td>
									<td><h2>";
									//output search terms if available
									if (isset($searchArray['Last_Name'])){
										$lastName = $searchArray['Last_Name'];
										echo" $lastName";
									}
									echo"</h2></td>
									<td><h2>";
									if (isset($searchArray['First_Name'])){
										$firstName = $searchArray['First_Name'];
										echo" $firstName";
									}
									echo"</h2></td>
									<td><h2>";
									if (isset($searchArray['Email'])){
										$email = $searchArray['Email'];
										echo" $email";
									}
									echo"</h2></td>
									<td><h2>";
									if (isset($searchArray['Phone'])){
										$phone = $searchArray['Phone'];
										echo" $phone";
									}
									echo"</h2></td>
									<td><h2>";
									if (isset($searchArray['Com_ID'])){
										$companyName = getCompanyName($searchArray['Com_ID']);
										echo" $companyName";
									}
									echo"</h2></td>
									<td><h2>";
									if (isset($searchArray['Account_Type'])){
										$accountType = $searchArray['Account_Type'];
										$typeName = [];
										$typeName = getTypeName($accountType, null);
										$out = $typeName[0];
										echo" $out";
									}
									echo"</td></tr>";
									
									
									
								//keep track of the accounts printed out to pass them to sendMail() without having to query the database again
								$i = 0;
								$IDarray = [];
								while($row = $result -> fetch_assoc()){
									$clientID = $row['Client_ID'];
									$companyID = $row['Com_ID'];
									$companyName = getCompanyName($companyID);
									$firstName = $row['First_Name'];
									$lastName = $row['Last_Name'];
									$phone = $row['Phone'];
									$email = $row['Email'];
									$typeID = $row['Account_Type'];
									$typeArray = getTypeName($typeID, 1);
									$type = $typeArray[0];
									$toolTip = $typeArray[1];
									//if the email is not set let there be a textbox to input an email to send the account out but if the account has been sent out and not filled out show N/A
									if ($email == 0 && $typeID == 0){
										$email = "<input type='email' placeholder='Email' name='$clientID'>";
										$freeAvailable = null;
									}
									elseif ($typeID == 1 && $email == 0){
										$email = 'N/A';
										
									}
									if($lastName == 0){
										
										$lastName = 'N/A';
										
									}
									if($firstName == 0){
										
										$firstName = 'N/A';
										
									}
									if($phone == 0){
										
										$phone = 'N/A';
										
									}
									if($email == 0){
										
										$email = 'N/A';
										
									}
									
									echo"
										<tr>
										<td>$clientID</td>
										<td>$lastName</td>
										<td>$firstName</td>
										<td>$email</td>
										<td>$phone</td>
										<td>$companyName</td>									
										<td class='tooltip'>
											$type
											<span class='tooltiptext'>$toolTip</span>
										</td>
										<td>
											<input type='checkbox' value='$clientID' name='$i'>
										</td>
										</tr>
										";
									$i++;
								}
								
								echo'</table>';
								
							}
							elseif (isset($_SESSION['isSent'])){
								//hide selection screen view output
								$selectStart = '<!--';
								$selectEnd = '-->';
								$hidden = 'hidden';
								$hidden2 = null;
								$freeAvailable = null;
								//get emails by client ID and status by client ID for display
								$isSent = [];
								$isSent = $_SESSION['isSent'];
								unset($_SESSION['isSent']);
								unset($_SESSION['emailByID']);
								echo"<h3>Email status:</h3>
									<table>
									<tr>
									<th><h2>Client ID:</h2></th>
									<th><h2>Email:</h2></th>
									<th><h2>Account Status:</h2></th>
									
									</tr>";
								foreach ($isSent as $clientID => $sendStatus){
									$email = $_SESSION["$clientID"];
									if($sendStatus == 1){
										
										$status = 'Email Sent<br>Status: Pending';
										
									}
									elseif($sendStatus == 0){
										
										$status = 'Email failed to send<br>Status: Free';
										
									}
									else{
										
										$status = 'Unknown error occurred';
										
									}
									echo"
											<tr>
											<td>$clientID</td>
											<td>$email</td>
											<td>$status</td>
											</tr>
										";
		
		
								}
								echo'</table>';
							}
							
							?>
							<?=$selectStart?>
							<label for="firstn"><b>Select Company</b></label>

							<br>
									
							<div style="display: inline;">

							<select id="ansq2" name="companyName">
							
							<?php	
							//get company names with company ID and put them into a associative array with the ID pointing to the name
							//used to populate the dropdown and associate names with IDs for insertion into the database
							$sql = "SELECT Com_Name, Com_ID FROM company";
							$result = $conn->query($sql);
							$companyNameArray = [];
							while ($row = $result -> fetch_assoc())  {
								$companyNameArray[$row['Com_ID']] = $row['Com_Name'];
							}
							echo"<option value='none'>None</option>";
							foreach($companyNameArray as $name){
			
								echo"<option value=$name>$name</option>";
				
							}
							
							?>
							
							</select>
  
								<br><br>
							<label for="firstn"><b>Select Account Type</b></label>
					
							<br>
									
							<div style="display: inline;">

							<select id="ansq2" name="accountType">
							
							<?php	
							//get company names with company ID and put them into a associative array with the ID pointing to the name
							//used to populate the dropdown and associate names with IDs for insertion into the database
							
							
							echo"
							
							<option value='none'>None</option>
							<option value='free'>Free</option>
							<option value='pending'>Pending</option>
							<option value='client'>Client</option>
							<option value='admin'>Administrator</option>
							
							";
							$conn->close();
							?>
							
							</select>
  
								<br><br>
							</div>  
							</div>
							
							
							<label for="firstn"><b>Search by Email</b></label>

							<br>
									
							<div style="display: inline;">
							
								<input type='text' placeholder='Enter Client Email' name='email'>
							
							</div>
							<br><br>
							<label for="firstn"><b>Search by First Name</b></label>

							<br>
									
							<div style="display: inline;">
							
								<input type='text' placeholder='Enter Client First Name' name='firstName'>
							
							</div>
							<br><br>
							<label for="firstn"><b>Search by Last Name</b></label>

							<br>
									
							<div style="display: inline;">
							
								<input type='text' placeholder='Enter Client Last Name' name='lastName'>
							
							</div>
							<br><br>
							<label for="firstn"><b>Search by Phone Number</b></label>

							<br>
									
							<div style="display: inline;">
							
								<input type='text' maxlength="10" placeholder='(___)-___-____' name='phone'>
							
							</div>
							<br>
							
							<br><br><br>
					
						<button type="submit" title="to view all accounts reset the form and select View Accounts" name="view">View Accounts</button>
							
							
						<button type="reset" name="reset">Reset</button>
						<br><br>
						</div>
						<button type="submit" value="View" name="return">Back to Generate</button><?=$selectEnd?>
						<button type="submit" name="sendMail"<?=$hidden?><?=$freeAvailable?>>Send Emails</button>
						<button type="submit" value="edit" name="edit"<?=$edit?>>Edit Accounts</button>
						<button type="submit" value="refresh" name="reload"<?=$hidden?>>Save For Later</button>
						<br>
							  
					
				</div>
				<br>
				<button type="submit" value="refresh" name="reload"<?=$hidden?>>Select Different Accounts</button>
				<button type="submit" value="refresh" name="reload"<?=$hidden2?>>Return to View Accounts</button>
			</form>
		</article>
	</div>
</body>
<footer></footer>
</html>