<?php
session_start();

/*if (!isset($_SESSION['clientID'])){
	
	header('Location: unlogged.php');
	
	}
else*/if (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}

?>
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Sleep App | Home</title>
  <link rel="stylesheet" href="sleepApp.css">
  <style>
  .wrapper {
  margin: 0;
  display: grid;
  grid-template-areas:
    "header nav"
    "main main"
    "footer footer";
  width: 100%;
}

header {
  grid-area: header;
  color: white;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
  
}
nav {
  grid-area: nav;
  color: #c4e3ec;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}

article {
  grid-area: main;
  color: #243236;
  background-color: #8fc9d9;
  width: 100%;
  height: auto;
}

footer {
  grid-area: footer;
  background-color: #48656d;
  width: 100%;
  height: 50px;
}

a {
  color: #243236;
}

  h1.appName {
  text-align: center;
}

.homeBox {
  width: 40%;
  background-color: #c4e3ec;
  text-align: center;
  margin: 20px auto;
}
p {
  font-size: 0.75em;
  margin-top: -10px;
}

.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 1.2em;
  border: none;
  outline: none;
  color: #8fc9d9;
  font-weight: bold;
  background-color: inherit;
  font-family: inherit;
  padding: 5px 15px 0px 15px;
}

nav a:hover,
.dropdown:hover .dropbtn {
  color: #243236;
  border-top: 4px solid #243236;
  font-weight: bold;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #c4e3ec;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: #243236;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  border: none;
  color: #fff;
  background-color: #243236;
}

.dropdown:hover .dropdown-content {
  display: block;
}
  </style>
</head>
<body>
    <div class="wrapper">
	<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
	
	
	
		<nav>
            <a href="home.php">Home</a>
            <div class="dropdown">
              <button class="dropbtn">Surveys
                <i class="fa fa-caret-down"></i>
              </button>
              <div class="dropdown-content">
                <a href="daySurvey.php">Daily Survey</a>
                <a href="ISSI.php">Insomnia Severity Index</a>
                <a href="WPAI.php">Work Productivity and Activity Impairment</a>
              </div>
              </div>
            <a href="profile.php">Profile</a>
            <a href="report.php">Report</a>
			<a href="helpPage.php">Help</a>
			</br>
			<form action="" method="post">
				<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
			</form>
			    
		</nav>
		
        <article>
          <!-- This section is for the content-->
          <h1 class='appName'>App name</h1>
              <div class="homeBox">
                <h3><a href="profile.php">Profile</a></h3>
                <p>Change your password and edit your information</p>
              </div>
              <div class="homeBox">
                <h3><a href="daySurvey.php">Daily Survey</a></h3>
                <p>Record your progress daily with this survey</p>
              </div>
              <div class="homeBox">
                <h3><a href="report.php">Weekly Report</a></h3>
                <p>In a future update Weekly Report will show your progress over the week</p>
              </div>
              <div class="homeBox">
                <h3><a href="helpPage.php">Help</a></h3>
                <p>Instructions for taking surveys and FAQ</p>
              </div>
              
          

        </article>
		<br>
        <footer></footer>
    </div>
</body>
</html>