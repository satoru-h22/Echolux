<?php
//buffers output to ensure headers work where they need to work
ob_start();	

//setup the email server
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
//Load Composer's autoloader
require 'vendor/autoload.php';

function createUpdateAccount(){
	//routes incoming requests to the propper functions
	
	
	if(isset($_POST["profile"])){
		
		//set on profile.php as 1 to act as a flag for this function to send the script to the right switch in editAccount()
		editAccount(2);
		
	}
	elseif (isset($_REQUEST['changePass'])){
		//new account has been successfully verified by getAccountinfo() and has submitted data on clientInfo
		editAccount(5);
		
	}
	elseif (isset($_POST['code'])){
		//user has submitted a 6 digit code for review of its validity 
		getAccountinfo();
		
	}
	elseif (isset($_REQUEST['clientInfo'])){
		//new account has been successfully verified by getAccountinfo() and has submitted data on clientInfo
		editAccount(4);
		
	}
	elseif (isset($_REQUEST['IDs'])){
		//new account has been successfully verified by getAccountinfo() and has submitted data on clientInfo
		
		editAccount(6);
		
		
	}
	else{
		session_start();
		//no variables set send to login through editAccount()
		//$_POST['firstName'] = 0;
		//$_SESSION['firstName'] = 1;
		//print_r($_POST);
	//	header('Location: callCUA.php');
		//header("Location: callCUA.php");
		editAccount(3);

		
	}
	
}
	



function editAccount($editType){
	include 'config.php';
		//depending on the choice taken from createUpdateAccount this module will execute searchForAccount or getAccountinfo
	switch ($editType){
		//case 6 accounts have been created call view accounts 
		case '6':

		$_SESSION['IDs'] = $_REQUEST['IDs'];
		$_SESSION['companyName'] = $_REQUEST['companyName'];
	
		header('Location: viewAccounts.php');

		break;
		//case 5 the user has elected to change their password 
		case '5':
		$clientID = $_SESSION['clientID'];
		$cuPass = $_REQUEST['currentPass'];
		$hashPass = hash('sha512',$cuPass);
		$pass = $_REQUEST['pass'];
		$pass2 = $_REQUEST['pass2'];
		
		$hashID = hash('sha512',$clientID);
		$sql = "select Password from Password where Client_ID = '$hashID'";
		$result = $conn -> query($sql);
		$row = $result -> fetch_assoc();
		//salt is the hashed password that is returned from the database
		$salt = $row['Password'];
		
		if ($salt == $hashPass){
			
			if ($pass == $pass2){
				
				writeToAccount('chPass');
				
				
			}
			else{
				
				echo'<script>alert("passwords do not match")</script>';
				unset($_REQUEST);
			}
			
		}
		else{
			
			echo'<script>alert("Password is incorrect")</script>';
			unset($_REQUEST);
		}
		break;
		//case 4 a new user has submitted a correct account number and filled in the client information form
		case '4':
		$email = $_POST['editEmail'];
		$pass = $_POST['editPass'];
		$pass2 = $_POST['editPass2'];
			//
			$sql = "select * from Client where Email = '$email'";
			$result = $conn -> query($sql);
			$row = $result -> fetch_assoc();
	
			if ($row == null) {
		
			
				if ($pass == $pass2 && $pass != '0000'){

				$new = 'new';
				writeToAccount($new);
				
				}
				
				else{
				
				echo'<script>alert("passwords do not match")</script>';
				
				}
				
			}	
			else{
				
				echo'<script>alert("Email exists please choose another email")</script>';
				
			}
		
		break;
		//case 3 user arrives on the site
		case '3':
				header('Location: unlogged.php');
				exit();
			
		
		break;
		//case 2 get the value edited on profile and send to writeToAccount with the correct edit type
		case '2':
		//check to see if the user has changed their email or not. If they haven't we don't need to check to see if the email exists and if we did check the unchanged email the system would see the entry and deny write access
			$editEmail = $_REQUEST['editEmail'];
			$sessionEmail = $_SESSION['email'];
			if ($editEmail == $sessionEmail){
				$profile = 'profile';
				writeToAccount($profile);
				
				
			}
			else{
				//check to see if the email they changed to is already attached to another account
				$sql = "select * from Client where Email = '$editEmail'";
				$result = $conn -> query($sql);
				$row = $result -> fetch_assoc();
	
				if ($row == null) {
					$profile = 'profile';
					writeToAccount($profile);
				
				}
				else{
				
					echo'<script>alert("Email exists please choose another email")</script>';
					
				}
			
			}
			
		break;
		//case 1 the administrator has created a new account on POST editID
		case '1':
			getAccountinfo();
		break;
		//case 0 the administrator has selected to update an existing account
		case '0':
			searchForAccount();
		break;
		
		default: echo"</br>error. Unrecognized input</br>";
	}
	$conn->close();
}

function getAccountinfo(){
	include 'config.php';
		
	if (isset($_REQUEST['editID'])){
		//Admin is editing ID on editAccount grab all data from client where clientID is the account being edited and return an array of the client data
			$clientID = $_REQUEST['editID'];
			$sql = "select * from client where Client_ID = '$clientID'";
			$result = $conn -> query($sql);
			$row = $result -> fetch_assoc();
			
		
		return $row;
	}
	elseif (isset($_POST['code']) == true){
		session_start();
		
		//occurs when a new user is trying to set up an account and has submitted a code for varifacation 
			$code = $_POST['code'];
			$result = mysqli_query($conn, "select * from Client where Client_ID = $code");
			$numRow = $result -> num_rows;
			
			if($numRow == 0) {
				echo '<script>alert("Incorrect Access Code")</script>';
				session_destroy();
			}
			else{
				$row = $result -> fetch_assoc();
				//if there are results from the database the data is checked to see if the account has been set up already
				$firstName = $row['First_Name'];
				$lastName = $row['Last_Name'];
				$phone = $row['Phone'];
				$email = $row['Email'];
				if($firstName == '0' && $lastName == '0' && $phone == '0' && $email == '0'){
				
				$_SESSION['editClientID'] = $code;
					header('Location: clientInfo.php');
					exit();
				}
				else {
					
					echo'<script>alert("Incorrect Access Code")</script>';
					return 0;
				}
				
			}
		
		
		
	}
	else{
		echo'<script>alert("account type unrecognized please logout and log back in again")</script>';
		
	}
	$conn->close();
}

function writeToAccount($actType){
	include 'config.php';

	//this function writes to account with different privilages depending on what is passed
	switch ($actType){
		
		case"new":
		
			$clientID = $_SESSION['editClientID'];
			$hashID = hash('sha512',$clientID);
			$firstName = $_POST['editFirstName'];
			$lastName = $_POST['editLastName'];
			$phone = $_POST['editPhone'];
			$email = $_POST['editEmail'];
			$pass = $_POST['editPass'];
			$type = 2;
			
			

				$hashPass = hash('sha512',$pass);
				$sql = "update password set Password = '$hashPass' where Client_ID = '$hashID'";
				$conn -> query($sql);
				$sql2 = "update client set First_Name = '$firstName', Last_Name = '$lastName', Phone = '$phone', Email = '$email', Account_Type = '$type' where Client_ID = '$clientID'";
				$conn -> query($sql2);
				session_destroy();
				echo'<h2></h2>';
				unset($_REQUEST);
				header('Location: unlogged.php?msg');
				
				
			
			
		break;
		case 'profile':
			$clientID = $_SESSION['clientID'];
			$firstName = $_REQUEST['editFirstName'];
			$lastName = $_REQUEST['editLastName'];
			$phone = $_REQUEST['editPhone'];
			$email = $_REQUEST['editEmail'];
			
				
				$sql = "update client set First_Name = '$firstName', Last_Name = '$lastName', Phone = '$phone', Email = '$email' where Client_ID = '$clientID'";
				$conn -> query($sql);
				$_SESSION['firstName'] = $firstName;
				$_SESSION['lastName'] = $lastName;
				$_SESSION['phone'] = $phone;
				$_SESSION['email'] = $email;
				
			header("Refresh:0");
				
			
		
		break;
		//current and updated passwords are verified and need to be written to database
		case 'chPass':
		$clientID = $_SESSION['clientID'];	
		$hashID = hash('sha512',$clientID);
		$pass = $_REQUEST['pass'];
		$hashPass = hash('sha512',$pass);
		$sql = "update password set Password = '$hashPass' where Client_ID = '$hashID'";
		$conn -> query($sql);
		unset($_REQUEST);
		header('Location: profile.php?msg');
		
		
		break;
		case 'admin':
		echo'<script>alert("Find admin functions in a future update")</script>';
		break;
		default:
		echo'<script>alert("could not determine write permissions please try again")</script>';
		break;
		
		
	}	
		
	$conn->close();
}

//generates random 6 digit numbers, zero filling to the left, until one is not found in the Client table then inserts an account will null values in the client and password tables
function generateNewAccount($companyID){
	include 'config.php';
	
	do{	
	//once we get the interface for this screen it will be able to generate accounts on a specific companyID
		//generate 4 digit code and 0 fill if needed
		$random = rand(1,999999);
		$testID = str_pad($random,6,"0", STR_PAD_LEFT);
		//check if the random generated code exists already or not
		$sql = "select Client_ID from Client where Client_ID=$testID";	
		$result = $conn->query($sql);
		
	} while ($result == $testID);
		
	$inSQL = "INSERT INTO Client (Client_ID, Com_ID, First_Name, Last_Name, Phone, Email, Account_Type)
						values ($testID, $companyID, 0, 0, 0, 0, 0);";
	$conn->query($inSQL);
	//insert client into password table
	$hashID = hash('sha512',$testID);
	
	$SQL2 = "INSERT INTO password (Client_ID, Password)
						values ('$hashID', '0000');";
	$conn->query($SQL2);
	$conn->close();
	return $testID;
	
}

//accepts a company ID and returns the name of the company or 0 if none are found
function getCompanyName($companyID){
include 'config.php';

	$sql = "select Com_Name from company where Com_ID = $companyID";
	$result = $conn->query($sql);
	$row = $result -> fetch_assoc();
	if ($row == null){
		$conn->close();
		return 0;
		
	}
	else{
		$name = $row['Com_Name'];
		$conn->close();
		return $name;
		
		
	}
}
//accepts a company name and returns the associated company ID from the database or 0 if none are found
function getCompanyID($companyName){
	include 'config.php';

	$sql = "select Com_ID from company where Com_Name = '$companyName'";
	$result = $conn->query($sql);

	$row = $result -> fetch_assoc();
	if ($row == null){
		$conn->close();
		return 0;
		
	}
	else{
		$name = $row['Com_ID'];
		$conn->close();
		return $name;
		
		
	}
	$conn -> close();
}
//accepts a single digit int and a bool value and returns the account type as string or returns an array containing the name and description of the account Type
function getTypeName($type, $option){
	if ($option == null){
		switch($type){
			case '0':
				return 'free';
			break;
			case '1':
				return 'pending';
			break;
			case '2':
				return 'client';
			break;
			case '3':
				return 'admin';
			break;
			default:
				return 'unknown';
		
	}
	}
	else{
		$array = [];
		switch($type){
		case '0':
			$array['0'] = 'free';
			$array['1'] = 'Account has no data and is ready to be sent to a new client';
			return $array;
		break;
		case '1':
			$array['0'] = 'pending';
			$array['1'] = 'Account has been sent to a client the account has not been set up by the client';
			return $array;
		break;
		case '2':
			$array['0'] = 'client';
			$array['1'] = 'fully filled out account with non-admin privilages';
			return $array;
		break;
		case '3':
			$array['0'] = 'admin';
			$array['1'] = 'Administrator account';
			return $array;
		break;
		default:
			return 'unknown';
		
	}
		
		
	}
}
//accepts a string and returns account type as int or unknown
function getTypeID($type){
	
	switch($type){
		case 'free':
			return '0';
		break;
		case 'pending':
			return '1';
		break;
		case 'client':
			return '2';
		break;
		case 'admin':
			return '3';
		break;
		default:
			return 'unknown';
	}
	
}
//accepts an array of client IDs and takes emails from the post array if they have been provided
//requires a type 0 being a password recovery email and 1 being the new client email
function prepMail($type){
	//edit the contents of mail.php to password recov or new account setup
	include 'config.php';
	if ($type == 1){
		
		$issent = [];
		$emails = [];
		foreach($_REQUEST as $clientID => $email){
			if ($email != null){
				//setup contents of mail.php
				$title = 'Welcome <br> Please follow the link below to setup your account';
				$preLink = "your signup code is: $clientID";
				$link = 'http://172.22.2.74/SleepDB/test%20site/Register.php?link=' . $clientID . '';
				$linkText = 'setup account';
				$subject = 'Setup your account';
				ob_start();
				include 'mail.php';
				//get the contents of mail.php
				$content = ob_get_contents();
				ob_end_clean();
				
				$isSent[$clientID] = sendMail($clientID, $email, $subject, $content);
				//set account status to pending if email is sent 
				if ($isSent[$clientID] == 1){
					$sql = "update client set Account_Type = 1 where Client_ID = '$clientID'";
					$conn->query($sql);
				}
				$emails[$clientID] = $email;
				$_SESSION["$clientID"] = $emails[$clientID];
			}
			
		}
		
		
		$_SESSION['isSent'] = $isSent;
		$conn->close();
		//header('Location: viewAccounts.php');
	
	}
	elseif ($type == 0){
	
		foreach($_REQUEST as $clientID => $email){
			//setup contents of mail.php
			$title = 'Welcome <br> Please follow the link below to reset your password';
			$preLink = "your reset code is: $clientID";
			$link = 'http://172.22.2.74/SleepDB/test%20site/START.php';
			$linkText = 'Reset Password';
			$subject = 'Password Reset';
			ob_start();
			include 'mail.php';
			//get the contents of mail.php
			$content = ob_get_contents();
			ob_end_clean();
			sendMail($clientID, $email, $subject, $content);
			$conn->close();
		}
		
	}
	else{
	$conn->close();
	return "$type invalid";
	
	}
	
	

}
//accepts an ID, email, and the html content to send in the email
function sendMail($clientID, $email, $subject, $content){
	
//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);


try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'emlynsworkshop@gmail.com';                     //SMTP username
    $mail->Password   = 'jackotheshadows';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('LanaWalshCoaching@SleepApp.com', 'Lana Walsh Coaching');
	//Add a recipient
    $mail->addAddress($email);               //Name is optional
	//no reply
    //$mail->addReplyTo('info@example.com', 'Information');
	//no need to cc or bcc
	//$mail->addCC('cc@example.com');
	//$mail->addBCC('bcc@example.com');
	
	
	//attachments unnecessary 
    //Attachments
    //$mail->addAttachment('/var/tmp/file.tar.gz');         //Add attachments
	//$mail->addAttachment('/tmp/image.jpg', 'new.jpg');    //Optional name

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = $subject;
    $mail->Body    = $content;
    $mail->AltBody = 'Unable to render html please try again';

    $mail->send();
     return 1;
	 
} 
catch (Exception $e) {
	return "Message to $email could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
	

}

//accepts a value such as an email, first name, last name, or phone number and a type describing which value has been passed 
function searchForAccount($value, $type){
	include 'config.php';
	if ($value == 'all'){
		$sql = 'select * from client';
		$result = $conn->query($sql);
		return $result;
		
	}
	
	$conn->close();
}
//checks request values from viewAccounts and returns the values that are not none or null
function getSearch(){
	//all if statements to check each 
	if(isset($_REQUEST["companyName"]) && $_REQUEST["companyName"] != None){
		
	}
	if($_REQUEST["accountType"]){
		
	}
	if($_REQUEST["email"]){
		
	}
	if($_REQUEST["firstName"]){
		
	}
	if($_REQUEST["lastName"]){
		
	}
	if($_REQUEST["phone"]){
		
	}
	
	
}

?>
