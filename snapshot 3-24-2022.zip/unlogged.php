<?php
session_start();

if(isset($_GET['msg'])){
	unset($_SESSION);
	unset($_REQUEST);
	session_destroy();
	
	header('Location: loginform.php?msg');

}
else{
unset($_SESSION);
unset($_REQUEST);
session_destroy();
header('Location: loginform.php');
}
?>