<?php
session_start();
include 'createUpdateAccount.php';
include 'config.php';
if (isset($_SESSION['accountType']) && $_SESSION['accountType'] == 0){
	
	header('Location: unlogged.php');
	
	}
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}
elseif (isset($_REQUEST['create'])){
	
	$name = $_REQUEST['name'];
	$name = preg_replace('/\s+/', '_', $name);
	$email = $_REQUEST['email'];
	$phone = $_REQUEST['phone'];
	$memo = $_REQUEST['memo'];
	
	$sql = "select Com_Name from company where Com_Name = '$name'";
	$result = $conn->query($sql);
	$row = $result -> fetch_assoc();
	if ($row == null){
		
		$conn->close();
		
		
	}
	else{
		
		echo"<script>alert('Company $name exists choose another name')</script>";
		
	}
	
	do{
	//once we get the interface for this screen it will be able to generate accounts on a specific companyID
		//generate 4 digit code and 0 fill if needed
		$random = rand(1,9999);
		$testID = str_pad($random,4,"0", STR_PAD_LEFT);
		//check if the random generated code exists already or not
		$continue = 1;
		$checkName = getCompanyName($testID);
		
		if($checkName = 0){
			
			$continue = 0;
			
		}
		
		
	} while ($continue = 1);
		
	$inSQL = "INSERT INTO company (Com_ID, Com_Name, Com_Email, Com_Phone, Com_Memo)
						values ('$testID', '$name', '$email', '$phone', '$memo');";
	$conn->query($inSQL);
	//insert client into password table
	$hashID = hash('sha512',$testID);
	
	$SQL2 = "INSERT INTO password (Client_ID, Password)
						values ('$hashID', '0000');";
	$conn->query($SQL2);
	$conn->close();
	return $testID;

}
$conn->close();
?>
<!doctype html>

<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Sleep App | Home</title>
  <link rel="stylesheet" href="sleepApp.css">
 
</head>
<style>
.wrapper {
  margin: 0;
  display: grid;
  grid-template-areas:
    "header nav"
    "main main"
    "footer footer";
  width: 100%;
}
input[type=text], input[type=number] {
	width: 35%;
	padding: 12px 20px;
	margin: 8px 0;
	display: inline-block;
	border: 1px solid #ccc;
	box-sizing: border-box;
	text-align: center;
}
header {
  grid-area: header;
  color: white;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
  
}
nav {
  grid-area: nav;
  color: #c4e3ec;
  background-color: #48656d;
  width: 100%;
  height: 80px;
  padding: 10px;
}

article {
  grid-area: main;
  color: #243236;
  background-color: #8fc9d9;
  width: 100%;
  height: 650px;
}

footer {
  grid-area: footer;
  background-color: #48656d;
  width: 100%;
  height: 50px;
}

a {
  color: #243236;
}

  h1.appName {
  text-align: center;
}

.homeBox {
  width: 40%;
  background-color: #c4e3ec;
  text-align: center;
  margin: 20px auto;
}
p {
  font-size: 0.75em;
  margin-top: -10px;
}

.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
</style>
<body>
    <div class="wrapper">
		<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
		<div>
			<nav>
				<a href="adminHome.php">Home</a>
				<a href="generateNewAccount.php">Generate New Account</a>
				<a href="viewAccounts.php">View Accounts</a>
				<a href="export.php">Export DB</a>
				<a href="createCompany.php">Create Company</a>
				<br>
				<form action="" method="post">
					<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
				</form>
			</nav>
		</div>
        <article>
			<div style="border-bottom: 1px solid #243236;">
				<h2>Create Company</h2>
			</div>
			<div style="border-bottom: 1px solid #243236;">
				<br>
				<form action="" method="post">
				<input type='text' placeholder='Company Name' name='name' required>
				<br>
				<input type='text' placeholder='Company Email' name='email' required>
				<br>
				<input id="phone" type="text" name="phone" maxlength="10" placeholder="(___)-___-____" pattern="\([0-9]{3}\)\-[0-9]{3}\-[0-9]{4}$" required>
				<br>
				<input type='text' placeholder='Company description' name='memo' required>
				<br><br><br>
				</div>
				<br>
				<button type="submit" method="POST" name="create">Create Company</button>
				<br><br>
				</form>
			
        </article>
        <footer></footer>
    </div>
</body>
</html>