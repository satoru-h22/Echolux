<?php
include 'createUpdateAccount.php';
include 'config.php';
session_start();
//ensure no one can access this page without being logged in first
if (!isset($_SESSION['clientID'])){
	
	header('Location: unlogged.php');
	
	}
//log out the user if the logout button is selected
elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
}
elseif(isset($_GET['msg'])){
	
	echo'<script>alert("Password Changed")</script>';

}

//get stuff from login session to determine the right user data to display 
//these values are used in the html to display user info
$clientID = $_SESSION["clientID"];
$firstName = $_SESSION['firstName'];
$lastName = $_SESSION['lastName'];
$phone = $_SESSION['phone'];
$email = $_SESSION['email'];
$administrator = $_SESSION['admin'];

//this variable will be used to change a single button to do different things when pressed multiple times
$editSubmit = 'Edit';

if(isset($_REQUEST['chpass'])){
	
	header('Location: changePass.php');
	
}

if(isset($_REQUEST['cancel'])){
	
	unset($_REQUEST);
	
}
elseif(isset($_REQUEST['Edit'])){
	$editSubmit = 'Submit';
}
elseif(isset($_REQUEST['Submit'])){
	$_POST['profile'] = 1;
	createUpdateAccount();
	$editSubmit = 'Edit';
}


?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Sleep App | Profile</title>
	<link rel="stylesheet" href="sleepApp.css">
</head>
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
  background-color: #c4e3ec;
}
.dropdown {
  float: left;
  overflow: hidden;
}

.dropdown .dropbtn {
  font-size: 1.2em;
  border: none;
  outline: none;
  color: #8fc9d9;
  font-weight: bold;
  background-color: inherit;
  font-family: inherit;
  padding: 5px 15px 0px 15px;
}

nav a:hover,
.dropdown:hover .dropbtn {
  color: #243236;
  border-top: 4px solid #243236;
  font-weight: bold;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: #c4e3ec;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
  z-index: 1;
}

.dropdown-content a {
  float: none;
  color: #243236;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
  border: none;
  color: #fff;
  background-color: #243236;
}

.dropdown:hover .dropdown-content {
  display: block;
}
h1.appName {
  font-size: 2em;
  text-align: center;
}


/* Full-width input fields */
input[type=text], input[type=password] {
  width: 50%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: 1px solid #ccc;
  background: #f1f1f1;
  box-sizing: border-box;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: rgb(228, 220, 220);
  outline: rgb(5, 5, 5);
}
.logout {
  line-height: 12px;
  width: 100px;
  font-size: 10pt;
  margin-top: 15px;
  margin-right: 2px;
  position: absolute;
  top: 35px;
  right: 35px;
}
</style>

<body>
	<div class="wrapper">
		<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
	
	
	
		<nav>
            <a href="home.php">Home</a>
            <div class="dropdown">
              <button class="dropbtn">Surveys
                <i class="fa fa-caret-down"></i>
              </button>
              <div class="dropdown-content">
                <a href="daySurvey.php">Daily Survey</a>
                <a href="ISSI.php">Insomnia Severity Index</a>
                <a href="WPAI.php">Work Productivity and Activity Impairment</a>
              </div>
              </div>
            <a href="profile.php">Profile</a>
            <a href="report.php">Report</a>
			<a href="helpPage.php">Help</a>
			</br>
			<form action="" method="post">
				<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
			</form>
			    
		</nav>
		<article>
			<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
				 
				<div class="container">

					<div class="profile">

						<!--first name-->
						<div style="border-bottom: 1px solid #243236;">
							<label for="firstn"><b>First Name:</b></label>

							<br><br>
									  
							<div style="display: inline;">

							<div>
										  
							<label style="text-align:left;" for="runame"><b><?=$firstName?></b></label> 
							<?PHP
							if(isset($_POST['Edit'])){
		
							echo"</br><input type='text' placeholder='Enter First Name' value='$firstName' name='editFirstName' required>";
	
							}
							
							?>
								
							</div>

							
										
							<br><br><br>

							</div>                    
						</div>
						<br>

						<!--last name-->
						<div style="border-bottom: 1px solid #243236;">
							<label for="firstn"><b>Last Name:</b></label>

							<br><br>
									
							<div style="display: inline;">

								<div>
											
									<label style="text-align:left;" for="runame"><b><?=$lastName?></b></label> 
									<?PHP
									if(isset($_POST['Edit'])){
			
										echo"</br><input type='text' placeholder='Enter Last Name' value='$lastName' name='editLastName' required>";
	
									}
							
									?>										
										
								</div>

								
										  
								<br><br><br>

							</div>                    
						</div>
						<br> 


						

							  
						<!--phone-->
						<div style="border-bottom: 1px solid #243236;">
							<label for="firstn"><b>Phone:</b></label>

							<br><br>
									
							<div style="display: inline;">

							<div>
										
							<label style="text-align:left;" for="runame"><b><?=$phone?></b></label> 
							<?PHP
							if(isset($_POST['Edit'])){
								//parse phone number into cohearent data
								echo"
								</br>
								
								<input id='phone' type='tel' name='editPhone' maxlength='10' value='$phone' placeholder='(___)-___-____' pattern='\([0-9]{3}\)\-[0-9]{3}\-[0-9]{4}$' required>";
	
							}
							
							?>									  
							</div>

							
									  
							<br><br><br>

							</div>                    
						</div>
						<br>


						<!--email-->
						<div style="border-bottom: 1px solid #243236;">
							<label for="firstn"><b>Email:</b></label>

							<br><br>
									
							<div style="display: inline;">

							<div>
										
							<label style="text-align:left;" for="runame"><b><?=$email?></b></label> 
							<?PHP
							if(isset($_POST['Edit'])){
			
								echo"</br><input type='text' placeholder='Enter Email' value='$email' name='editEmail' required>";
	
							}
							
							?>		  
							</div>

							
									  
							<br><br><br>

							</div>                    
						</div>
						<br>


						<!--email-->
						<!--company-->
						<?PHP
						//won't show the company unless a client is not an individual
						$companyID = $_SESSION['comID'];
						if($companyID == '0001'){
							
						}
						else{
						$companyName = getCompanyName($companyID);
						echo"
						
						<div style='border-bottom: 1px solid #243236;'>
							<label for='firstn'><b>Company:</b></label>

							<br><br>
									
								<div style='display: inline;'>

									<div>
											
									<label style='text-align:left;' for='runame'><b>$companyName</b></label> 
									  
									</div>

									<br><br><br>

								</div>                    
						</div>";
						}
						?>
						<!--company-->
						<br>							
						<br>
								
						<button type="submit" name="<?=$editSubmit?>"><?=$editSubmit?></button>
						<?PHP
						//if users hit cancel the form is hidden the cancel button will only appear after clicking on edit
						if(isset($_POST['Edit'])){
			
							echo'<button type="submit" class="cancelbtn">Cancel</button>';
	
						}
							
						?>
						<br>
							<button type="submit" name="chpass" class="cancelbtn">Change Password</button>  
						<br>
					</div>
				</div>

				  
			</form>
		</article>
	</div>
</body>
<footer></footer>
</html>