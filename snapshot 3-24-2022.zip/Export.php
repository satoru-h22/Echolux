<?php
	include "config.php";
	include "createUpdateAccount.php";
	if (isset($_SESSION['admin']) && $_SESSION['admin'] == 0){
	
	header('Location: unlogged.php');
	
	}
	elseif (isset($_REQUEST['logOut'])){
	
	header('Location: unlogged.php');
	
	}
	
?>





<html lang="en">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="sleepApp.css">
<body>
	<header>
      <div class="headerS">/ </div>
      <div class="headerLogo">Lana Walsh<br>Coaching</div>
       <div class="headerSub">Sleep App: Helping you Conquer Insomnia so <br>You Wake up Feeling Rested and Refreshed</div>
      
    </header>
			<nav>
				<a href="adminHome.php">Home</a>
				<a href="generateNewAccount.php">Generate New Account</a>
				<a href="viewAccounts.php">View Accounts</a>
				<a href="export.php">Export DB</a>
				<a href="createCompany.php">Create Company</a>
				<br>
				<form action="" method="post">
					<button class = "logout" type="submit" method="POST" name="logOut">Log Out</button>
				</form>
			</nav>
<!-- Export link -->
<div class="col-md-12 head">
    <div class="float-right">
        <a href="exportData.php" class="btn btn-success"><i class="dwn"></i> Export</a>
    </div>
</div>

<!-- Data list table --> 
<table class="table table-striped table-bordered">
    <thead class="thead-dark">
        <tr>
            <th>Name</th>
            <th>Question</th>
            <th>Date</th>
            <th>Answer</th>
        </tr>
    </thead>
    <tbody>
   <?php 
    // Fetch records from database 
    $result = $conn->query("SELECT c1.First_Name, c2.Question, p.Date, p.Answer
	FROM answer p
	LEFT JOIN  client c1 ON p.Client_ID = c1.Client_ID 
	LEFT JOIN  question c2 ON p.Qu_ID = c2.Qu_ID 
	ORDER BY p.Date ASC"); 
    if($result->num_rows > 0){ 
        while($row = $result->fetch_assoc()){ 
    ?>
        <tr>
            <td><?php echo $row['First_Name']; ?></td>
            <td><?php echo $row['Question']; ?></td>
            <td><?php echo $row['Date']; ?></td>
            <td><?php echo $row['Answer']; ?></td>
            
        </tr>
    <?php } }else{ ?>
        <tr><td colspan="7">No member(s) found...</td></tr>
    <?php } ?>
    </tbody>
</table>
</body
</html>